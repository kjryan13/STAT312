#R Basics (Download Project R from http://www.r-project.org and open it)

#R is a vector language
#R code can be run interactively (one line at a time)
#  or R code can be run all at once
#On a given line, R ignores everything after a pound sign #.
#Cut and paste the lines into R one at a time to learn more about the following.
     #(1) MAKING VECTORS
     #(2) GETTING HELP
     #(3) PLOTTING
     #(4) BASIC NUMERICAL SUMMARIES
     #(5) MATRIX ALGEBRA


#####################################################
#(1) MAKING VECTORS (Four basic ways :, seq, rep, c)#
#####################################################
1:10 #Use the colon operator :

x=1:10 #Assignment only
x
(x=-5:5) #Assignment+print

x+10 #Elementwise arithmetic on vectors
exp(x)
cos(x)
x^2
sqrt(x+10)

seq(1,10,.1) #Sequence from 1 through 10 incrementing by .1
rep(5,6)     #6 repetitions of 5

rnorm(10) #A random sample of size 10 from Z~N(0,1)

c(1, 3, 7:10, rnorm(10)) #Use c for concatenate or combine


##############################################
#(2) GETTING HELP: R has very good help menus#
##############################################
help.start() #Will start R help menus
?rnorm       #Will provide help on the rnorm function
rnorm        #Shows the arguments for the function rnorm


############################################
#(3) PLOTTING (scatterplots and histograms)#
############################################
pi
x=seq(0,3*pi,.1)
plot(x, cos(x))           #Points only by default
plot(x, cos(x), type="l") #l for line only
plot(x, cos(x), type="b") #b for both--points and a line

#Signal plus noise example
(t=seq(.1,20,.1))
(length(t))
(signal=cos(t))
(noise=rnorm(length(t), sd=0.5))
plot(t, signal+noise, main="Example: Signal + Noise", xlab="t", ylab="Response")
lines(t, signal)

hist(rnorm(1000), xlim=c(-4, 4), main="Random Sample of n=1,000 from N(0,1)", xlab="z")
#Run this last line 10 times. Use the up arrow to repeat a statement in R
#Note the minor changes in the histogram after a new sample is obtained


###############################
#(4) BASIC NUMERICAL SUMMARIES#
###############################
(dat=1:10)
mean(dat)
var(dat)
sqrt(var(dat)) 
sd(dat) #Standard deviation: Same as previous line
summary(dat)

mean(rnorm(10000)) #Should be close to 0
var(rnorm(10000))  #Should be close to 1
#Repeat these last two statements. This helps you study the sampling
#distribution of sample mean and sample variance, respectively, when
#taking size n=10,000 samples from N(0,1).


####################
#(5) MATRIX ALGEBRA#
####################
(X=matrix(1:4, nrow=2)) #Convert a vector to a matrix
(X=matrix(1:4, nrow=2, byrow=TRUE)) #Not the same matrix!!!!!
matrix #Typing function with no () shows its arguments

X
X[2,1] #Print the 2nd row, 1st column entry of matrix X
X+X
X*X #Elementwise--not matrix multiplication
X%*%X #The operator %*% is for matrix multiplication in R
det(X) #Determinant of X
X[1,1]*X[2,2]-X[1,2]*X[2,1] #Should match previous line
dim(X) #Dimension of X: nrows ncols

(Xinv=solve(X)) #The inverse of X
X%*%Xinv  #Should be a 2x2 identity within rounding error
Xinv%*%X  #Should be a 2x2 identity within rounding error

X
t(X)  #Transpose of a matrix

diag(8) #An 8x8 identity matrix

################
#End of Program#
################